** THIS example is not for production use.  It is only an example implementation! **

** Before beginning go into crop.php and change your upload path! **

There is a bit of resizing and crop work to be done on your part, this is just an 
example of how to get the script croordinating with uploadify, Impromptu, and jcrop.

When you begin your own implementation you will need to do some image prep work in 
uploadify.php, as well as crop.php (or whereever you decide to place it.
